# -*- coding: utf-8 -*-
"""
    cocoscrapers Project - Torznab Provider
"""

import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode, quote_plus
from cocoscrapers.modules import client, source_utils, log_utils
from cocoscrapers.modules import control
from time import time


class source:
    priority = 1
    pack_capable = True
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en']
        self.item_totals = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'CAM': 0}
        self.min_seeders = 0
        self._base_url = None
        self._api_key = None

    def _get_settings(self):
        if self._base_url is None:
            self._base_url = control.setting('torznab.serverurl').rstrip('/')
            self._api_key = control.setting('torznab.apikey')

    def _is_configured(self):
        self._get_settings()
        return bool(self._base_url and self._api_key)

    def _build_url(self, params):
        self._get_settings()
        params['apikey'] = self._api_key
        return '%s?%s' % (self._base_url, urlencode(params))

    def _parse_response(self, xml_text):
        results = []
        if not xml_text:
            return results
        try:
            ns = {'torznab': 'http://torznab.com/schemas/2015/feed'}
            root = ET.fromstring(xml_text)
            for item in root.findall('./channel/item'):
                try:
                    name = item.findtext('title', '').strip()
                    link = item.findtext('link', '').strip()
                    infohash = ''
                    seeders = 0
                    size = 0

                    for attr in item.findall('torznab:attr', ns):
                        attr_name = attr.get('name', '')
                        attr_val = attr.get('value', '')
                        if attr_name == 'infohash':
                            infohash = attr_val.lower()
                        elif attr_name == 'seeders':
                            try:
                                seeders = int(attr_val)
                            except ValueError:
                                seeders = 0
                        elif attr_name == 'size':
                            try:
                                size = int(attr_val)
                            except ValueError:
                                size = 0

                    if size == 0:
                        enclosure = item.find('enclosure')
                        if enclosure is not None:
                            try:
                                size = int(enclosure.get('length', 0))
                            except (ValueError, TypeError):
                                size = 0
                    if size == 0:
                        size_text = item.findtext('size', '0')
                        try:
                            size = int(size_text)
                        except ValueError:
                            size = 0

                    if not infohash and link.startswith('magnet:'):
                        match = re.search(r'btih:([a-fA-F0-9]{40,64})', link, re.I)
                        if match:
                            infohash = match.group(1).lower()

                    if not infohash:
                        continue

                    magnet = link if link.startswith('magnet:') else \
                        'magnet:?xt=urn:btih:%s&dn=%s' % (infohash, quote_plus(name))

                    results.append({
                        'hash': infohash,
                        'magnet': magnet,
                        'name': name,
                        'seeders': seeders,
                        'size': size,
                    })
                except Exception:
                    source_utils.scraper_error('TORZNAB')
        except ET.ParseError:
            log_utils.log('TORZNAB: Failed to parse XML response', log_utils.LOGWARNING)
        return results

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        if not self._is_configured():
            log_utils.log('TORZNAB: Not configured — set Server URL and API Key in settings', log_utils.LOGWARNING)
            return sources
        sources_append = sources.append
        try:
            startTime = time()
            aliases = data.get('aliases', [])
            year = data.get('year', '')
            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()

            if 'tvshowtitle' in data:
                title = data['tvshowtitle'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                episode_title = data.get('title')
                hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
                years = None
                params = {
                    't': 'tvsearch',
                    'q': re.sub(r'[^A-Za-z0-9\s\.-]+', '', title),
                    'season': int(data['season']),
                    'ep': int(data['episode']),
                }
                tvdb_id = data.get('tvdb_id') or data.get('tvdb') or ''
                if tvdb_id:
                    params['tvdbid'] = tvdb_id
            else:
                title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                episode_title = None
                hdlr = year
                years = [str(int(year) - 1), str(year), str(int(year) + 1)]
                params = {
                    't': 'movie',
                    'q': re.sub(r'[^A-Za-z0-9\s\.-]+', '', title),
                    'year': year,
                }
                imdb_id = data.get('imdb', '')
                if imdb_id:
                    params['imdbid'] = re.sub(r'\D', '', imdb_id)

            url = self._build_url(params)
            response = client.request(url, output='extended', timeout=10)
            if not response:
                return sources
            if response[1] not in ('200', '201'):
                log_utils.log('TORZNAB: Request failed for (%s) : %s' % (url, response))
                return sources

            items = self._parse_response(response[0])
            for item in items:
                try:
                    name = source_utils.clean_name(item['name'])
                    if not source_utils.check_title(title, aliases, name, hdlr, year, years):
                        continue
                    name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                    if source_utils.remove_lang(name_info, check_foreign_audio):
                        continue
                    if undesirables and source_utils.remove_undesirables(name_info, undesirables):
                        continue

                    if not episode_title:
                        ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
                        if any(re.search(p, name.lower()) for p in ep_strings):
                            continue

                    seeders = item['seeders']
                    if self.min_seeders > seeders:
                        continue

                    quality, info = source_utils.get_release_quality(name_info, item['magnet'])
                    try:
                        dsize, isize = source_utils.convert_size(float(item['size']), to='GB')
                        info.insert(0, isize)
                    except Exception:
                        dsize = 0
                    info = ' | '.join(info)

                    sources_append({
                        'provider': 'torznab', 'source': 'torrent', 'seeders': seeders,
                        'hash': item['hash'], 'name': name, 'name_info': name_info,
                        'quality': quality, 'language': 'en', 'url': item['magnet'],
                        'info': info, 'direct': False, 'debridonly': True, 'size': dsize,
                    })
                    self.item_totals[quality] += 1
                except Exception:
                    source_utils.scraper_error('TORZNAB')

            logged = False
            for quality in self.item_totals:
                if self.item_totals[quality] > 0:
                    log_utils.log('#STATS - TORZNAB found {0:2.0f} {1}'.format(self.item_totals[quality], quality))
                    logged = True
            if not logged:
                log_utils.log('#STATS - TORZNAB found nothing')
            log_utils.log('#STATS - TORZNAB took %.2f seconds' % (time() - startTime))
        except Exception:
            source_utils.scraper_error('TORZNAB')
        return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
        self.sources = []
        if not data:
            return self.sources
        if not self._is_configured():
            return self.sources
        self.sources_append = self.sources.append
        try:
            startTime = time()
            self.search_series = search_series
            self.total_seasons = total_seasons
            self.bypass_filter = bypass_filter
            self.title = data['tvshowtitle'].replace('&', 'and').replace('Special Victims Unit', 'SVU').replace('/', ' ').replace('$', 's')
            self.aliases = data.get('aliases', [])
            self.imdb = data.get('imdb', '')
            self.year = data.get('year', '')
            self.season_x = data['season']
            self.season_xx = self.season_x.zfill(2)
            self.undesirables = source_utils.get_undesirables()
            self.check_foreign_audio = source_utils.check_foreign_audio()
            self.item_totals = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'CAM': 0}

            clean_title = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)
            if search_series:
                queries = [clean_title + ' Season', clean_title + ' Complete']
            else:
                queries = [
                    clean_title + ' S%s' % self.season_xx,
                    clean_title + ' Season %s' % self.season_x,
                ]

            for q in queries:
                params = {'t': 'tvsearch', 'q': q}
                tvdb_id = data.get('tvdb_id') or data.get('tvdb') or ''
                if tvdb_id:
                    params['tvdbid'] = tvdb_id
                url = self._build_url(params)
                self._get_pack_sources(url)

            logged = False
            for quality in self.item_totals:
                if self.item_totals[quality] > 0:
                    log_utils.log('#STATS - TORZNAB(pack) found {0:2.0f} {1}'.format(self.item_totals[quality], quality))
                    logged = True
            if not logged:
                log_utils.log('#STATS - TORZNAB(pack) found nothing')
            log_utils.log('#STATS - TORZNAB(pack) took %.2f seconds' % (time() - startTime))
        except Exception:
            source_utils.scraper_error('TORZNAB')
        return self.sources

    def _get_pack_sources(self, url):
        try:
            response = client.request(url, output='extended', timeout=10)
            if not response or response[1] not in ('200', '201'):
                return
            items = self._parse_response(response[0])
        except Exception:
            source_utils.scraper_error('TORZNAB')
            return

        for item in items:
            try:
                name = source_utils.clean_name(item['name'])
                episode_start, episode_end = 0, 0
                if not self.search_series:
                    if not self.bypass_filter:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(
                            self.title, self.aliases, self.year, self.season_x, name)
                        if not valid:
                            continue
                    package = 'season'
                else:
                    if not self.bypass_filter:
                        valid, last_season = source_utils.filter_show_pack(
                            self.title, self.aliases, self.imdb, self.year,
                            self.season_x, name, self.total_seasons)
                        if not valid:
                            continue
                    else:
                        last_season = self.total_seasons
                    package = 'show'

                name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
                if source_utils.remove_lang(name_info, self.check_foreign_audio):
                    continue
                if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables):
                    continue

                seeders = item['seeders']
                if self.min_seeders > seeders:
                    continue

                quality, info = source_utils.get_release_quality(name_info, item['magnet'])
                try:
                    dsize, isize = source_utils.convert_size(float(item['size']), to='GB')
                    info.insert(0, isize)
                except Exception:
                    dsize = 0
                info = ' | '.join(info)

                entry = {
                    'provider': 'torznab', 'source': 'torrent', 'seeders': seeders,
                    'hash': item['hash'], 'name': name, 'name_info': name_info,
                    'quality': quality, 'language': 'en', 'url': item['magnet'],
                    'info': info, 'direct': False, 'debridonly': True, 'size': dsize,
                    'package': package,
                }
                if self.search_series:
                    entry['last_season'] = last_season
                elif episode_start:
                    entry.update({'episode_start': episode_start, 'episode_end': episode_end})
                self.sources_append(entry)
                self.item_totals[quality] += 1
            except Exception:
                source_utils.scraper_error('TORZNAB')
