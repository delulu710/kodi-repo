# -*- coding: utf-8 -*-
"""
    cocoscrapers Project - Newznab Provider (NZB / Usenet)
    Compatible with: SceneNZBs, NZBGeek, DrunkenSlug, etc.
"""

import re
import xml.etree.ElementTree as ET
from urllib.parse import urlencode
from cocoscrapers.modules import client, source_utils, log_utils
from cocoscrapers.modules import control
from time import time


class source:
    priority = 1
    pack_capable = False
    hasMovies = True
    hasEpisodes = True

    def __init__(self):
        self.language = ['en']
        self.item_totals = {'4K': 0, '1080p': 0, '720p': 0, 'SD': 0, 'CAM': 0}
        self._base_url = None
        self._api_key = None

    def _get_settings(self):
        if self._base_url is None:
            self._base_url = control.setting('newznab.serverurl').rstrip('/')
            self._api_key = control.setting('newznab.apikey')

    def _is_configured(self):
        self._get_settings()
        return bool(self._base_url and self._api_key)

    def _build_url(self, params):
        self._get_settings()
        params['apikey'] = self._api_key
        return '%s?%s' % (self._base_url, urlencode(params))

    def _parse_response(self, xml_text):
        results = []
        if not xml_text:
            return results
        try:
            ns = {'newznab': 'http://www.newznab.com/DTD/2010/feeds/attributes/'}
            root = ET.fromstring(xml_text)
            for item in root.findall('./channel/item'):
                try:
                    name = item.findtext('title', '').strip()
                    nzb_url = item.findtext('link', '').strip()
                    size = 0

                    for attr in item.findall('newznab:attr', ns):
                        attr_name = attr.get('name', '')
                        attr_val = attr.get('value', '')
                        if attr_name == 'size':
                            try:
                                size = int(attr_val)
                            except ValueError:
                                size = 0

                    if size == 0:
                        enclosure = item.find('enclosure')
                        if enclosure is not None:
                            try:
                                size = int(enclosure.get('length', 0))
                            except (ValueError, TypeError):
                                size = 0

                    if not nzb_url or not name:
                        continue

                    results.append({
                        'name': name,
                        'url': nzb_url,
                        'size': size,
                    })
                except Exception:
                    source_utils.scraper_error('NEWZNAB')
        except ET.ParseError as e:
            log_utils.log('NEWZNAB: Failed to parse XML: %s' % e, log_utils.LOGWARNING)
        return results

    def sources(self, data, hostDict):
        sources = []
        if not data:
            return sources
        if not self._is_configured():
            log_utils.log('NEWZNAB: Not configured — set Server URL and API Key in settings', log_utils.LOGWARNING)
            return sources
        sources_append = sources.append
        try:
            startTime = time()
            aliases = data.get('aliases', [])
            year = data.get('year', '')
            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()

            if 'tvshowtitle' in data:
                title = data['tvshowtitle'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                episode_title = data.get('title')
                hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
                years = None
                params = {
                    't': 'tvsearch',
                    'q': re.sub(r'[^A-Za-z0-9\s\.-]+', '', title),
                    'season': int(data['season']),
                    'ep': int(data['episode']),
                    'cat': '5000',
                }
                tvdb_id = data.get('tvdb_id') or data.get('tvdb') or ''
                if tvdb_id:
                    params['tvdbid'] = tvdb_id
                imdb_id = data.get('imdb', '')
                if imdb_id:
                    params['imdbid'] = re.sub(r'\D', '', imdb_id)
            else:
                title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                episode_title = None
                hdlr = year
                years = [str(int(year) - 1), str(year), str(int(year) + 1)]
                params = {
                    't': 'movie',
                    'q': re.sub(r'[^A-Za-z0-9\s\.-]+', '', title),
                    'year': year,
                    'cat': '2000',
                }
                imdb_id = data.get('imdb', '')
                if imdb_id:
                    params['imdbid'] = re.sub(r'\D', '', imdb_id)

            url = self._build_url(params)
            response = client.request(url, output='extended', timeout=15)
            if not response:
                return sources
            if response[1] not in ('200', '201'):
                log_utils.log('NEWZNAB: Request failed for (%s) : %s' % (url, response))
                return sources

            items = self._parse_response(response[0])
            for item in items:
                try:
                    name = source_utils.clean_name(item['name'])
                    if not source_utils.check_title(title, aliases, name, hdlr, year, years):
                        continue
                    name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                    if source_utils.remove_lang(name_info, check_foreign_audio):
                        continue
                    if undesirables and source_utils.remove_undesirables(name_info, undesirables):
                        continue

                    if not episode_title:
                        ep_strings = [r'[.-]s\d{2}e\d{2}([.-]?)', r'[.-]s\d{2}([.-]?)', r'[.-]season[.-]?\d{1,2}[.-]?']
                        if any(re.search(p, name.lower()) for p in ep_strings):
                            continue

                    quality, info = source_utils.get_release_quality(name_info, name)
                    try:
                        dsize, isize = source_utils.convert_size(float(item['size']), to='GB')
                        info.insert(0, isize)
                    except Exception:
                        dsize = 0
                    info = ' | '.join(info)

                    sources_append({
                        'provider': 'newznab', 'source': 'usenet', 'seeders': 100,
                        'name': name, 'name_info': name_info,
                        'quality': quality, 'language': 'en', 'url': item['url'],
                        'info': info, 'direct': False, 'debridonly': True, 'size': dsize,
                    })
                    self.item_totals[quality] += 1
                except Exception:
                    source_utils.scraper_error('NEWZNAB')

            logged = False
            for quality in self.item_totals:
                if self.item_totals[quality] > 0:
                    log_utils.log('#STATS - NEWZNAB found {0:2.0f} {1}'.format(self.item_totals[quality], quality))
                    logged = True
            if not logged:
                log_utils.log('#STATS - NEWZNAB found nothing')
            log_utils.log('#STATS - NEWZNAB took %.2f seconds' % (time() - startTime))
        except Exception:
            source_utils.scraper_error('NEWZNAB')
        return sources

    def sources_packs(self, data, hostDict, search_series=False, total_seasons=None, bypass_filter=False):
        return []
